# Databricks notebook source
# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM spotify_catalog.gold.dimuser;

# COMMAND ----------

